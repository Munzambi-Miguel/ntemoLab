<?php

namespace App\Http\Livewire\Layouts;

use Livewire\Component;

class TopNavBar extends Component
{
    public function render()
    {
        return view('livewire.layouts.top-nav-bar');
    }
}
