<?php

namespace App\Http\Livewire\Util\Listas\Profiles;

use Livewire\Component;

class ProfileList extends Component
{
    public function render()
    {
        return view('livewire.util.listas.profiles.profile-list');
    }
}
