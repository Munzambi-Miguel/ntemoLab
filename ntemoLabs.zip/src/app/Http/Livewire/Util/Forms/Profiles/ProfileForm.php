<?php

namespace App\Http\Livewire\Util\Forms\Profiles;

use Livewire\Component;

class ProfileForm extends Component
{
    public function render()
    {
        return view('livewire.util.forms.profiles.profile-form');
    }
}
